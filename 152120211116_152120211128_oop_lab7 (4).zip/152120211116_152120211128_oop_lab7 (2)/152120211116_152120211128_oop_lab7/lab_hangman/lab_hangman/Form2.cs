﻿// Form2.cs
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace lab_hangman
{
    public partial class Form2 : Form
    {
        private string kategoriAdi;
        private ZorlukSeviyesi zorlukSeviyesi;
        private int oyunSuresiAyari;
        private string secilenTema;
        string kategori;
        string zorluk;
        int sure;
        string tema;

        private Soru aktifSoru;
        private Timer oyunZamanlayicisi;
        private int kalanSure;
        private string bilinecekKelime;
        private string gosterilenKelime;
        private int puan = 100;
        private int yanlisTahminSayisi = 0;
        private List<char> yanlisHarfler = new List<char>();

        private Label lblOyunBilgisiDisplay;

        private Dictionary<string, int> temaSonResimIndexi = new Dictionary<string, int>
        {
            { "AdamAs", 9 },
            { "ÇöpAdamAs", 9 },
            { "ÇiçekKopar", 9 },
            { "BalonPatlat", 9 }
        };
        private int mevcutTemaKaybetmeLimiti;

        public Form2(string kategori, string zorluk, int sure, string tema)
        {
            InitializeComponent();
            
            this.kategori = kategori;
            this.zorluk = zorluk;
            this.sure = sure;
            this.tema = tema;

            kategoriAdi = kategori;
            Enum.TryParse(zorluk, out zorlukSeviyesi);
            oyunSuresiAyari = sure;
            secilenTema = tema;

            string temaKey = secilenTema.Replace(" ", "");
            if (temaSonResimIndexi.TryGetValue(temaKey, out int sonResimIdx))
                mevcutTemaKaybetmeLimiti = sonResimIdx + 1;
            else
                mevcutTemaKaybetmeLimiti = 9;

            InitializeOyunBilgiLabel();
            if (string.IsNullOrEmpty(tema))
            {
                this.tema = "Adam As"; 
            }

        }

        private void InitializeOyunBilgiLabel()
        {
            Control[] foundControls = this.Controls.Find("lblOyunBilgisiDisplay", true);
            if (foundControls.Length > 0 && foundControls[0] is Label)
            {
                lblOyunBilgisiDisplay = (Label)foundControls[0];
            }
            else
            {
                lblOyunBilgisiDisplay = new Label
                {
                    Name = "lblOyunBilgisiDisplay",
                    Location = new Point(10, 8),
                    AutoSize = true,
                    Font = new Font("Segoe UI", 14F, FontStyle.Bold),
                    ForeColor = Color.Black,
                    Text = "Oyun Bilgileri Yükleniyor..."
                };
                this.Controls.Add(lblOyunBilgisiDisplay);
                lblOyunBilgisiDisplay.BringToFront();
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            lblOyunBilgisiDisplay.Text = $"Süre: {oyunSuresiAyari:D2}sn - Kategori: {kategoriAdi} - Seviye: {zorlukSeviyesi}";
            
            YeniOyunBaslat();

        }

        private void YeniOyunBaslat()
        {
            aktifSoru = SoruBankasi.RastgeleSoruGetir(kategoriAdi, zorlukSeviyesi);

            if (aktifSoru == null || string.IsNullOrEmpty(aktifSoru.Kelime))
            {
                MessageBox.Show("Bu kategori ve zorlukta uygun soru bulunamadı!", "Soru Hatası");
                AnaMenuyeDon();
                return;
            }

            bilinecekKelime = aktifSoru.Kelime.ToLower();
            gosterilenKelime = new string('_', bilinecekKelime.Length);
            yanlisHarfler.Clear();
            yanlisTahminSayisi = 0;
            puan = 100;

            lblClue.Text = $"İpucu: {aktifSoru.Ipucu}";
            lblWordLength.Text = $"Harf Sayısı: {bilinecekKelime.Length}";
            lblScore.Text = $"Puan: {puan}";
            GuncelleKelimeGosterimini();
            GuncelleYanlisHarfleri();
            GuncelleAdamAsmacaResmini();


          
            kalanSure = (oyunSuresiAyari <= 0) ? 60 : oyunSuresiAyari;
            lblTimer.Text = $"Kalan Süre: {kalanSure} saniye";
            if (oyunZamanlayicisi == null)
            {
                oyunZamanlayicisi = new Timer();
                oyunZamanlayicisi.Interval = 1000;
                oyunZamanlayicisi.Tick += OyunZamanlayicisi_Tick;
            }
            oyunZamanlayicisi.Stop(); 
            kalanSure = (oyunSuresiAyari <= 0) ? 60 : oyunSuresiAyari;
            lblTimer.Text = $"Kalan Süre: {kalanSure} saniye";
            oyunZamanlayicisi.Start();


            txtGuess.Clear();
            txtGuess.Focus();
            this.BackColor = SystemColors.Control;
            lblTimer.ForeColor = SystemColors.ControlText;
        }

        private void GuncelleKelimeGosterimini()
        {
            lblWordDisplay.Text = string.Join(" ", gosterilenKelime.ToCharArray());
        }

        private void GuncelleYanlisHarfleri()
        {
            lblWrongLetters.Text = $"Yanlış Harfler: {string.Join(", ", yanlisHarfler)}";
        }

        private void GuncelleAdamAsmacaResmini()
        {

            try
            {
                string temaKlasoru = "";
                string resimFormat = "";
                int maxResimSayisi = 0;

                switch (secilenTema)
                {
                    case "Adam As":
                        temaKlasoru = "h";
                        resimFormat = yanlisTahminSayisi == 0 ? "cover.jpg" :
                                     yanlisTahminSayisi == 1 ? "cover2.jpg" :
                                     $"man-{yanlisTahminSayisi - 1:00}.jpg";
                        maxResimSayisi = 10; // man-00.jpg'den man-09.jpg'e kadar
                        break;

                    case "Çiçek Kopar":
                        temaKlasoru = "p";
                        resimFormat = $"a-{yanlisTahminSayisi}.jpg";
                        maxResimSayisi = 9; // a-0.jpg'den a-9.jpg'e kadar
                        break;

                    case "Balon Patlat":
                        temaKlasoru = "b";
                        resimFormat = $"b-{yanlisTahminSayisi}.jpg";
                        maxResimSayisi = 9; // b-0.jpg'den b-9.jpg'e kadar
                        break;
                }

              
                string imagePath = Path.Combine(Application.StartupPath, "Images", temaKlasoru, resimFormat);

                
                if (!File.Exists(imagePath) && yanlisTahminSayisi >= maxResimSayisi)
                {
                    imagePath = Path.Combine(Application.StartupPath, "Images", temaKlasoru,
                                           secilenTema == "Adam As" ? "man-09.jpg" :
                                           secilenTema == "Çiçek Kopar" ? "a-9.jpg" : "b-9.jpg");
                }

                if (File.Exists(imagePath))
                {
                 
                    if (picHangman.Image != null)
                    {
                        picHangman.Image.Dispose();
                        picHangman.Image = null;
                    }

                    
                    using (FileStream fs = new FileStream(imagePath, FileMode.Open, FileAccess.Read))
                    {
                        picHangman.Image = Image.FromStream(fs);
                    }
                }
                else
                {
                  
                    picHangman.Image = SystemIcons.Error.ToBitmap();
                }
            }
            catch (Exception ex)
            {
               
                Debug.WriteLine($"Resim yükleme hatası: {ex.Message}");
            }
        }

        private void OyunZamanlayicisi_Tick(object sender, EventArgs e)
        {
            
            kalanSure--;
            lblTimer.Text = $"Kalan Süre: {kalanSure} saniye";

            if (kalanSure <= 0)
            {
                oyunZamanlayicisi.Stop();
                this.BackColor = Color.DarkRed;
                lblTimer.ForeColor = Color.White;

                MessageBox.Show($"Süre bitti! Kaybettiniz.\nDoğru kelime: {bilinecekKelime.ToUpper()}",
                                "ZAMAN DOLDU", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                AnaMenuyeDon();
            }
        }

        private void btnGuess_Click(object sender, EventArgs e)
        {
            TahminiIsle();
        }

        private void txtGuess_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                TahminiIsle();
                e.Handled = true;
            }
            else if (!char.IsLetter(e.KeyChar) && !"ıİşŞğĞüÜöÖçÇ".Contains(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void TahminiIsle()
        {
            if (kalanSure <= 0 || !gosterilenKelime.Contains("_") || yanlisTahminSayisi >= mevcutTemaKaybetmeLimiti)
            {
                txtGuess.Clear();
                return;
            }

            string tahminInput = txtGuess.Text.Trim().ToLower();
            txtGuess.Clear();
            txtGuess.Focus();

            if (string.IsNullOrEmpty(tahminInput) || tahminInput.Length != 1) return;

            char tahminEdilenHarf = tahminInput[0];

            if (gosterilenKelime.Contains(tahminEdilenHarf) || yanlisHarfler.Contains(tahminEdilenHarf))
            {
                MessageBox.Show($"'{tahminEdilenHarf}' harfini daha önce denediniz.", "Tekrar Denendi");
                return;
            }

            bool harfBulundu = false;
            StringBuilder sb = new StringBuilder(gosterilenKelime);
            for (int i = 0; i < bilinecekKelime.Length; i++)
            {
                if (bilinecekKelime[i] == tahminEdilenHarf)
                {
                    sb[i] = tahminEdilenHarf;
                    harfBulundu = true;
                }
            }

            if (harfBulundu)
            {
                gosterilenKelime = sb.ToString();
                GuncelleKelimeGosterimini();

                if (!gosterilenKelime.Contains("_"))
                {
                    oyunZamanlayicisi.Stop();
                    this.BackColor = Color.PaleGreen;
                    MessageBox.Show($"Tebrikler! Kazandınız!\nKelime: {bilinecekKelime.ToUpper()}\nPuanınız: {puan}", "KAZANDINIZ!");
                    AnaMenuyeDon();
                }
            }
            else
            {
                yanlisHarfler.Add(tahminEdilenHarf);
                yanlisTahminSayisi++;
                puan = Math.Max(0, puan - 10);

                lblScore.Text = $"Puan: {puan}";
                GuncelleYanlisHarfleri();
                GuncelleAdamAsmacaResmini();

                if (yanlisTahminSayisi >= mevcutTemaKaybetmeLimiti || puan <= 0)
                {
                    oyunZamanlayicisi.Stop();
                    this.BackColor = Color.Tomato;
                    string message = puan <= 0 ? "Puanınız sıfırlandı!" : "Maksimum yanlış tahmin hakkınız doldu!";
                    MessageBox.Show($"{message}\nDoğru kelime: {bilinecekKelime.ToUpper()}", "KAYBETTİNİZ!");
                    AnaMenuyeDon();
                }

                
            }
        }

        private void btnEndGame_Click(object sender, EventArgs e)
        {
            oyunZamanlayicisi.Stop();
            DialogResult cevap = MessageBox.Show("Ana menüye dönmek istediğinize emin misiniz?", "Oyundan Çık", MessageBoxButtons.YesNo);
            if (cevap == DialogResult.Yes)
            {
                AnaMenuyeDon();
            }
            else
            {
                if (kalanSure > 0 && gosterilenKelime.Contains("_") && yanlisTahminSayisi < mevcutTemaKaybetmeLimiti)
                {
                    oyunZamanlayicisi.Start();
                    txtGuess.Focus();
                }
            }
        }

        private void AnaMenuyeDon()
        {
            Form anaMenu = Application.OpenForms["Form1"];
            if (anaMenu != null)
            {
                anaMenu.Show();
            }
            else
            {
                Form1 yeniAnaMenu = new Form1();
                yeniAnaMenu.Show();
            }
            this.Close();
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (oyunZamanlayicisi != null)
            {
                oyunZamanlayicisi.Stop();
                oyunZamanlayicisi.Dispose();
            }
            base.OnFormClosing(e);
        }
    }
}
