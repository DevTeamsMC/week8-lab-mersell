﻿namespace lab_hangman
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAyarlarıKaydet = new System.Windows.Forms.Button();
            this.cmbZorluk = new System.Windows.Forms.ComboBox();
            this.cmbSure = new System.Windows.Forms.ComboBox();
            this.cmbTema = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnAyarlarıKaydet
            // 
            this.btnAyarlarıKaydet.BackColor = System.Drawing.Color.DarkOliveGreen;
            this.btnAyarlarıKaydet.Location = new System.Drawing.Point(280, 380);
            this.btnAyarlarıKaydet.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnAyarlarıKaydet.Name = "btnAyarlarıKaydet";
            this.btnAyarlarıKaydet.Size = new System.Drawing.Size(458, 44);
            this.btnAyarlarıKaydet.TabIndex = 0;
            this.btnAyarlarıKaydet.Text = "KAYDET";
            this.btnAyarlarıKaydet.UseVisualStyleBackColor = false;
            this.btnAyarlarıKaydet.Click += new System.EventHandler(this.btnAyarlarıKaydet_Click);
            // 
            // cmbZorluk
            // 
            this.cmbZorluk.FormattingEnabled = true;
            this.cmbZorluk.Location = new System.Drawing.Point(27, 159);
            this.cmbZorluk.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cmbZorluk.Name = "cmbZorluk";
            this.cmbZorluk.Size = new System.Drawing.Size(132, 33);
            this.cmbZorluk.TabIndex = 1;
            // 
            // cmbSure
            // 
            this.cmbSure.FormattingEnabled = true;
            this.cmbSure.Location = new System.Drawing.Point(303, 159);
            this.cmbSure.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cmbSure.Name = "cmbSure";
            this.cmbSure.Size = new System.Drawing.Size(314, 33);
            this.cmbSure.TabIndex = 2;
            // 
            // cmbTema
            // 
            this.cmbTema.FormattingEnabled = true;
            this.cmbTema.Location = new System.Drawing.Point(738, 143);
            this.cmbTema.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cmbTema.Name = "cmbTema";
            this.cmbTema.Size = new System.Drawing.Size(200, 33);
            this.cmbTema.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(733, 86);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(118, 25);
            this.label1.TabIndex = 4;
            this.label1.Text = "Tema Seçin";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(311, 75);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 25);
            this.label2.TabIndex = 5;
            this.label2.Text = "Süre Seçin";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(18, 75);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(127, 25);
            this.label3.TabIndex = 6;
            this.label3.Text = "Seviye Seçin";
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.OliveDrab;
            this.ClientSize = new System.Drawing.Size(1066, 562);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmbTema);
            this.Controls.Add(this.cmbSure);
            this.Controls.Add(this.cmbZorluk);
            this.Controls.Add(this.btnAyarlarıKaydet);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.ForeColor = System.Drawing.Color.Transparent;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "Form3";
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAyarlarıKaydet;
        private System.Windows.Forms.ComboBox cmbZorluk;
        private System.Windows.Forms.ComboBox cmbSure;
        private System.Windows.Forms.ComboBox cmbTema;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}