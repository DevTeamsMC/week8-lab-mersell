﻿// SoruModel.cs
using System;
using System.Collections.Generic;
using System.Linq;

namespace lab_hangman // Projenizin namespace'i farklıysa burayı güncelleyin
{
    public enum ZorlukSeviyesi
    {
        Kolay,
        Orta,
        Zor
    }

    public class Soru
    {
        public string Kelime { get; set; }
        public string Ipucu { get; set; }
        public string Kategori { get; set; }
        public ZorlukSeviyesi Zorluk { get; set; }

        public Soru(string kelime, string ipucu, string kategori, ZorlukSeviyesi zorluk)
        {
            Kelime = kelime.ToLower(); // Kelimeler küçük harf olarak saklansın
            Ipucu = ipucu;
            Kategori = kategori;
            Zorluk = zorluk;
        }
    }

    public static class SoruBankasi
    {
        public static List<Soru> Sorular { get; private set; }

        static SoruBankasi()
        {
            Sorular = new List<Soru>
            {
                // --- TARİH (20+ Soru) ---
                new Soru("istanbul", "Osmanlı'nın fethettiği önemli bir şehir", "Tarih", ZorlukSeviyesi.Kolay),
                new Soru("fatihsultanmehmet", "İstanbul'u fetheden padişah", "Tarih", ZorlukSeviyesi.Orta),
                new Soru("lozan", "Türkiye Cumhuriyeti'nin bağımsızlık antlaşması", "Tarih", ZorlukSeviyesi.Zor),
                new Soru("malazgirt", "Anadolu'nun kapılarını Türklere açan savaş", "Tarih", ZorlukSeviyesi.Orta),
                new Soru("anıtkabir", "Atatürk'ün ebedi istirahatgahı", "Tarih", ZorlukSeviyesi.Kolay),
                new Soru("çanakkale", "Birinci Dünya Savaşı'nda önemli bir cephe", "Tarih", ZorlukSeviyesi.Orta),
                new Soru("metehan", "Asya Hun İmparatorluğu'nun kurucusu", "Tarih", ZorlukSeviyesi.Zor),
                new Soru("osmanbey", "Osmanlı Devleti'nin kurucusu", "Tarih", ZorlukSeviyesi.Kolay),
                new Soru("tarih", "Geçmişi inceleyen bilim dalı", "Tarih", ZorlukSeviyesi.Kolay),
                new Soru("yazı", "Sümerlerin icat ettiği iletişim aracı", "Tarih", ZorlukSeviyesi.Orta),
                new Soru("pirireis", "Ünlü Osmanlı denizcisi ve haritacısı", "Tarih", ZorlukSeviyesi.Zor),
                new Soru("cumhuriyet", "Türkiye'nin yönetim şekli", "Tarih", ZorlukSeviyesi.Kolay),
                new Soru("istiklal", "Türkiye'nin ulusal marşı", "Tarih", ZorlukSeviyesi.Kolay),
                new Soru("sultanahmet", "Mavi Camii olarak da bilinen yapı", "Tarih", ZorlukSeviyesi.Orta),
                new Soru("ayasofya", "Tarihi bir ibadethane ve müze", "Tarih", ZorlukSeviyesi.Orta),
                new Soru("kapitülasyon", "Osmanlı'da yabancılara tanınan ayrıcalıklar", "Tarih", ZorlukSeviyesi.Zor),
                new Soru("türk", "Orta Asya kökenli bir ulus", "Tarih", ZorlukSeviyesi.Kolay),
                new Soru("bilgekağan", "Göktürk hükümdarı", "Tarih", ZorlukSeviyesi.Zor),
                new Soru("selçuklu", "Büyük bir Türk İslam devleti", "Tarih", ZorlukSeviyesi.Orta),
                new Soru("haçlıseferleri", "Orta Çağ'da Hristiyanların düzenlediği seferler", "Tarih", ZorlukSeviyesi.Zor),
                new Soru("mimarsinan", "Osmanlı'nın en ünlü mimarı", "Tarih", ZorlukSeviyesi.Orta),
                new Soru("hititler", "Anadolu'da kurulan eski bir uygarlık", "Tarih", ZorlukSeviyesi.Orta),
                new Soru("kleopatra", "Antik Mısır'ın son kraliçesi", "Tarih", ZorlukSeviyesi.Zor),

                // --- COĞRAFYA (20+ Soru) ---
                new Soru("everest", "Dünyanın en yüksek dağı", "Coğrafya", ZorlukSeviyesi.Orta),
                new Soru("ankara", "Türkiye'nin başkenti", "Coğrafya", ZorlukSeviyesi.Kolay),
                new Soru("nil", "Dünyanın en uzun nehri", "Coğrafya", ZorlukSeviyesi.Zor),
                new Soru("van", "Türkiye'nin en büyük gölü", "Coğrafya", ZorlukSeviyesi.Orta),
                new Soru("amazon", "En büyük havzaya sahip nehir", "Coğrafya", ZorlukSeviyesi.Orta),
                new Soru("sahra", "Dünyanın en büyük sıcak çölü", "Coğrafya", ZorlukSeviyesi.Orta),
                new Soru("pasifik", "Dünyanın en büyük okyanusu", "Coğrafya", ZorlukSeviyesi.Kolay),
                new Soru("akdeniz", "Türkiye'nin güneyindeki deniz", "Coğrafya", ZorlukSeviyesi.Kolay),
                new Soru("italya", "Çizme şeklinde haritası olan ülke", "Coğrafya", ZorlukSeviyesi.Kolay),
                new Soru("japonya", "Doğan güneşin ülkesi", "Coğrafya", ZorlukSeviyesi.Orta),
                new Soru("kıta", "Büyük kara parçası", "Coğrafya", ZorlukSeviyesi.Kolay),
                new Soru("ekvator", "Dünyayı kuzey ve güney olarak ikiye ayıran çizgi", "Coğrafya", ZorlukSeviyesi.Orta),
                new Soru("volkan", "Yer kabuğundan magma püskürten dağ", "Coğrafya", ZorlukSeviyesi.Orta),
                new Soru("atmosfer", "Dünyayı çevreleyen gaz tabakası", "Coğrafya", ZorlukSeviyesi.Zor),
                new Soru("asya", "En büyük kıta", "Coğrafya", ZorlukSeviyesi.Kolay),
                new Soru("türkiye", "Başkenti Ankara olan ülke", "Coğrafya", ZorlukSeviyesi.Kolay),
                new Soru("kuzeyışıkları", "Kutuplarda görülen renkli ışıklar", "Coğrafya", ZorlukSeviyesi.Zor),
                new Soru("muson", "Güneydoğu Asya'da etkili mevsimsel rüzgar", "Coğrafya", ZorlukSeviyesi.Zor),
                new Soru("fayhattı", "Depremlerin sık olduğu yer kabuğu kırığı", "Coğrafya", ZorlukSeviyesi.Orta),
                new Soru("meridyen", "Kutupları birleştiren hayali çizgi", "Coğrafya", ZorlukSeviyesi.Orta),
                new Soru("delta", "Nehirlerin denize döküldüğü yerde oluşan birikinti", "Coğrafya", ZorlukSeviyesi.Zor),
                new Soru("izmir", "Ege'nin incisi olarak bilinen şehir", "Coğrafya", ZorlukSeviyesi.Kolay),
                new Soru("karadeniz", "Türkiye'nin kuzeyindeki deniz", "Coğrafya", ZorlukSeviyesi.Kolay),

                // --- MATEMATİK (20+ Soru) ---
                new Soru("üçgen", "Üç kenarı olan geometrik şekil", "Matematik", ZorlukSeviyesi.Kolay),
                new Soru("karekök", "Bir sayının karesini veren sayıyı bulma", "Matematik", ZorlukSeviyesi.Orta),
                new Soru("pi", "Bir dairenin çevresinin çapına oranı (sembol)", "Matematik", ZorlukSeviyesi.Zor),
                new Soru("toplama", "Sayıları bir araya getirme işlemi", "Matematik", ZorlukSeviyesi.Kolay),
                new Soru("çarpma", "Tekrarlı toplama işlemi", "Matematik", ZorlukSeviyesi.Kolay),
                new Soru("integral", "Türev işleminin tersi", "Matematik", ZorlukSeviyesi.Zor),
                new Soru("kare", "Dört kenarı eşit ve dik geometrik şekil", "Matematik", ZorlukSeviyesi.Kolay),
                new Soru("daire", "Merkezden eşit uzaklıktaki noktalar kümesi", "Matematik", ZorlukSeviyesi.Kolay),
                new Soru("bölme", "Bir sayıyı eşit parçalara ayırma", "Matematik", ZorlukSeviyesi.Kolay),
                new Soru("çıkarma", "Bir sayıdan başka bir sayıyı eksiltme", "Matematik", ZorlukSeviyesi.Kolay),
                new Soru("oran", "İki çokluğun karşılaştırılması", "Matematik", ZorlukSeviyesi.Orta),
                new Soru("denklem", "Bilinmeyen içeren eşitlik", "Matematik", ZorlukSeviyesi.Orta),
                new Soru("yüzde", "Bir sayının yüze bölünmesiyle elde edilen oran", "Matematik", ZorlukSeviyesi.Orta),
                new Soru("asal", "Sadece bire ve kendisine bölünebilen sayı", "Matematik", ZorlukSeviyesi.Orta),
                new Soru("türev", "Bir fonksiyonun anlık değişim hızı", "Matematik", ZorlukSeviyesi.Zor),
                new Soru("limit", "Bir fonksiyonun bir noktaya yaklaşırken aldığı değer", "Matematik", ZorlukSeviyesi.Zor),
                new Soru("geometri", "Şekilleri inceleyen matematik dalı", "Matematik", ZorlukSeviyesi.Kolay),
                new Soru("cebir", "Sayılar ve harflerle yapılan işlemler", "Matematik", ZorlukSeviyesi.Orta),
                new Soru("fonksiyon", "Bir girdiyi bir çıktıya eşleyen kural", "Matematik", ZorlukSeviyesi.Zor),
                new Soru("permütasyon", "Nesnelerin sıralanışı", "Matematik", ZorlukSeviyesi.Zor),
                new Soru("kombinasyon", "Nesnelerin seçimi", "Matematik", ZorlukSeviyesi.Zor),
                new Soru("logaritma", "Üstel fonksiyonun tersi", "Matematik", ZorlukSeviyesi.Zor),
                new Soru("polinom", "Değişken ve katsayılardan oluşan ifade", "Matematik", ZorlukSeviyesi.Orta),


                // --- GENEL KÜLTÜR (20+ Soru) ---
                new Soru("oksijen", "Yaşam için gerekli bir gaz", "Genel Kültür", ZorlukSeviyesi.Kolay),
                new Soru("fotosentez", "Bitkilerin besin üretme şekli", "Genel Kültür", ZorlukSeviyesi.Orta),
                new Soru("atom", "Maddenin en küçük yapı taşı", "Genel Kültür", ZorlukSeviyesi.Orta),
                new Soru("mozart", "Ünlü bir klasik müzik bestecisi", "Genel Kültür", ZorlukSeviyesi.Zor),
                new Soru("monalisa", "Leonardo da Vinci'nin ünlü tablosu", "Genel Kültür", ZorlukSeviyesi.Orta),
                new Soru("su", "H2O formülüne sahip yaşam kaynağı", "Genel Kültür", ZorlukSeviyesi.Kolay),
                new Soru("güneş", "Güneş sistemimizin merkezi yıldızı", "Genel Kültür", ZorlukSeviyesi.Kolay),
                new Soru("ay", "Dünya'nın uydusu", "Genel Kültür", ZorlukSeviyesi.Kolay),
                new Soru("kitap", "Bilgi ve hikaye içeren basılı eser", "Genel Kültür", ZorlukSeviyesi.Kolay),
                new Soru("internet", "Dünya çapında bilgisayar ağı", "Genel Kültür", ZorlukSeviyesi.Orta),
                new Soru("dna", "Genetik bilgiyi taşıyan molekül", "Genel Kültür", ZorlukSeviyesi.Zor),
                new Soru("enerji", "İş yapabilme yeteneği", "Genel Kültür", ZorlukSeviyesi.Orta),
                new Soru("ışık", "Görmemizi sağlayan elektromanyetik dalga", "Genel Kültür", ZorlukSeviyesi.Orta),
                new Soru("ses", "Titreşimlerin oluşturduğu dalga", "Genel Kültür", ZorlukSeviyesi.Orta),
                new Soru("renk", "Işığın farklı dalga boylarının algılanması", "Genel Kültür", ZorlukSeviyesi.Kolay),
                new Soru("newton", "Yerçekimi kanununu bulan bilim insanı", "Genel Kültür", ZorlukSeviyesi.Zor),
                new Soru("einstein", "İzafiyet teorisini geliştiren bilim insanı", "Genel Kültür", ZorlukSeviyesi.Zor),
                new Soru("futbol", "On birer kişilik iki takım arasında oynanan top oyunu", "Genel Kültür", ZorlukSeviyesi.Kolay),
                new Soru("satranç", "Strateji ve zeka oyunu", "Genel Kültür", ZorlukSeviyesi.Orta),
                new Soru("müzik", "Seslerin ritmik ve melodik düzeni", "Genel Kültür", ZorlukSeviyesi.Kolay),
                new Soru("resim", "Boyalarla yüzeye yapılan görsel sanat", "Genel Kültür", ZorlukSeviyesi.Kolay),
                new Soru("bakteri", "Tek hücreli mikroorganizma", "Genel Kültür", ZorlukSeviyesi.Orta),
                new Soru("teleskop", "Uzak cisimleri gözlemleme aracı", "Genel Kültür", ZorlukSeviyesi.Orta)
            };
        }

        public static Soru RastgeleSoruGetir(string kategori, ZorlukSeviyesi zorluk)
        {
            List<Soru> uygunSorular;

            if (kategori.Equals("Karma", StringComparison.OrdinalIgnoreCase))
            {
                // Karma seçilirse, sadece zorluk seviyesine göre tüm kategorilerden filtrele
                uygunSorular = Sorular.Where(s => s.Zorluk == zorluk).ToList();
            }
            else
            {
                // Belirli bir kategori ve zorluk seviyesine göre filtrele
                uygunSorular = Sorular.Where(s => s.Kategori.Equals(kategori, StringComparison.OrdinalIgnoreCase) && s.Zorluk == zorluk).ToList();
            }

            // Eğer belirtilen zorlukta soru bulunamazsa, o kategorideki herhangi bir soruyu getir (zorluk gözetmeksizin)
            if (uygunSorular.Count == 0 && !kategori.Equals("Karma", StringComparison.OrdinalIgnoreCase))
            {
                uygunSorular = Sorular.Where(s => s.Kategori.Equals(kategori, StringComparison.OrdinalIgnoreCase)).ToList();
            }
            // Eğer hala soru yoksa (kategoride hiç soru yoksa veya karma ve belirtilen zorlukta hiç soru yoksa)
            // tüm sorulardan rastgele bir tane getir (zorluk gözetmeksizin)
            if (uygunSorular.Count == 0)
            {
                uygunSorular = Sorular.ToList(); // Tüm sorular
                if (uygunSorular.Count == 0) // Hiç soru yoksa varsayılan (bu durum olmamalı)
                    return new Soru("kelime", "Varsayılan ipucu", "Genel Kültür", ZorlukSeviyesi.Kolay);
            }

            Random rnd = new Random();
            return uygunSorular[rnd.Next(uygunSorular.Count)];
        }
    }
}