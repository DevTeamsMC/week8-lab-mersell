﻿// Form1.cs
using System;
using System.Drawing.Drawing2D;
using System.Drawing;
using System.Windows.Forms;

namespace lab_hangman // Projenizin namespace'i farklıysa burayı güncelleyin
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            // Kategorileri ComboBox'a yükle
            cmbKategori.Items.Clear(); // Önce temizle (varsa)
            cmbKategori.Items.Add("Tarih");
            cmbKategori.Items.Add("Coğrafya");
            cmbKategori.Items.Add("Matematik");
            cmbKategori.Items.Add("Genel Kültür");
            cmbKategori.Items.Add("Karma");

            if (cmbKategori.Items.Count > 0)
                cmbKategori.SelectedIndex = 0; // Varsayılan olarak ilk kategoriyi seç
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            if (cmbKategori.SelectedItem == null)
            {
                MessageBox.Show("Lütfen bir kategori seçin.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string secilenKategori = cmbKategori.SelectedItem.ToString();
           
            // Enum değerini almak için doğru özelliği kullan
            ZorlukSeviyesi secilenZorlukEnum;
            if (!Enum.TryParse(Form3.OyunAyarlar.Zorluk, out secilenZorlukEnum))
            {
                secilenZorlukEnum = ZorlukSeviyesi.Orta; // Varsayılan zorluk
            }

            // Form2'ye parametre olarak doğru verileri gönder
            Form2 oyunFormu = new Form2(secilenKategori, secilenZorlukEnum.ToString(), Form3.OyunAyarlar.Sure, Form3.OyunAyarlar.Tema);
            oyunFormu.Show();
            this.Hide();
        }
        private void MakeButtonRounded(Button btn)
        {
            GraphicsPath path = new GraphicsPath();
            int radius = 20; // köşe yuvarlaklığı (piksel)
            Rectangle rect = new Rectangle(0, 0, btn.Width, btn.Height);
            path.AddArc(rect.X, rect.Y, radius, radius, 180, 90);
            path.AddArc(rect.Right - radius, rect.Y, radius, radius, 270, 90);
            path.AddArc(rect.Right - radius, rect.Bottom - radius, radius, radius, 0, 90);
            path.AddArc(rect.X, rect.Bottom - radius, radius, radius, 90, 90);
            path.CloseAllFigures();

            btn.Region = new Region(path);
        }

        private void btnAyarlar_Click(object sender, EventArgs e)
        {
            Form3 ayarFormu = new Form3();
            if (ayarFormu.ShowDialog() == DialogResult.OK)
            {
                //// Form3'teki ayarları al
                string zorluk = ayarFormu.SecilenZorluk;
                int sure = ayarFormu.SecilenSure;
                string tema = ayarFormu.SecilenTema;
                
                // Bu değerleri Form2'ye parametre olarak gönderebilirsin
                // ya da Form1 içinde bir yerde saklayabilirsin
                MessageBox.Show($"Zorluk: {zorluk}, Süre: {sure}, Tema: {tema}");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
         MakeButtonRounded(btnStart);
            btnAyarlar.BackgroundImage = Image.FromFile(@"C:\Users\Mersel\Desktop\152120211116_152120211128_oop_lab7 (2)\152120211116_152120211128_oop_lab7\lab_hangman\lab_hangman\Images\setting.png");
            // Proje klasöründe olmalı
            btnAyarlar.BackgroundImageLayout = ImageLayout.Zoom;
            btnAyarlar.FlatStyle = FlatStyle.Flat;
            btnAyarlar.FlatAppearance.BorderSize = 0;
            btnAyarlar.BackColor = Color.Transparent;
            btnAyarlar.Size = new Size(40, 40); // Dilersen değiştir
        }
    }
}