﻿// Form3.cs
using System;
using System.Drawing.Drawing2D;
using System.Drawing;
using System.Windows.Forms;

namespace lab_hangman
{
    public partial class Form3 : Form
    {
        public string SecilenZorluk { get; private set; }
        public int SecilenSure { get; private set; }
        public string SecilenTema { get; private set; }
        public static class OyunAyarlar
        {
            public static string Zorluk { get; set; } = "Orta";
            public static int Sure { get; set; } = 60; 
            public static string Tema { get; set; } = "Adam As";
        }

        public Form3()
        {
            InitializeComponent();
            LoadDefaultComboBoxItems();
            LoadCurrentSettingsToComboBoxes();
        }

        private void LoadDefaultComboBoxItems()
        {
            cmbZorluk.Items.Clear();
            cmbZorluk.Items.Add("Kolay");
            cmbZorluk.Items.Add("Orta");
            cmbZorluk.Items.Add("Zor");

            cmbSure.Items.Clear();
            cmbSure.Items.Add("30");
            cmbSure.Items.Add("60");
            cmbSure.Items.Add("90");
            cmbSure.Items.Add("120");

            cmbTema.Items.Clear();
            cmbTema.Items.Add("Adam As");
         
  cmbTema.Items.Add("Çiçek Kopar");
            cmbTema.Items.Add("Balon Patlat");
        }

        private void LoadCurrentSettingsToComboBoxes()
        {
            // Zorluk
            string zorlukAyar = OyunAyarlar.Zorluk;
            if (cmbZorluk.Items.Contains(zorlukAyar))
            {
                cmbZorluk.SelectedItem = zorlukAyar;
            }
            else if (cmbZorluk.Items.Count > 0)
            {
                cmbZorluk.SelectedIndex = 1; 
                OyunAyarlar.Zorluk = cmbZorluk.SelectedItem.ToString(); 
            }

            // Süre
            string sureAyarStr = OyunAyarlar.Sure.ToString();
            if (cmbSure.Items.Contains(sureAyarStr))
            {
                cmbSure.SelectedItem = sureAyarStr;
            }
            else if (cmbSure.Items.Count > 0)
            {
                cmbSure.SelectedIndex = 1;
                OyunAyarlar.Sure = int.Parse(cmbSure.SelectedItem.ToString()); 
            }

            // Tema
            string temaAyar = OyunAyarlar.Tema;
            if (cmbTema.Items.Contains(temaAyar))
            {
                cmbTema.SelectedItem = temaAyar;
            }
            else if (cmbTema.Items.Count > 0)
            {
                cmbTema.SelectedIndex = 0; 
                OyunAyarlar.Tema = cmbTema.SelectedItem.ToString(); 
            }
        }

       

        private void Form3_Load(object sender, EventArgs e)
        {
            
            LoadCurrentSettingsToComboBoxes();
            MakeButtonRounded(btnAyarlarıKaydet);
        }
        private void MakeButtonRounded(Button btn)
        {
            GraphicsPath path = new GraphicsPath();
            int radius = 20; 
            Rectangle rect = new Rectangle(0, 0, btn.Width, btn.Height);
            path.AddArc(rect.X, rect.Y, radius, radius, 180, 90);
            path.AddArc(rect.Right - radius, rect.Y, radius, radius, 270, 90);
            path.AddArc(rect.Right - radius, rect.Bottom - radius, radius, radius, 0, 90);
            path.AddArc(rect.X, rect.Bottom - radius, radius, radius, 90, 90);
            path.CloseAllFigures();

            btn.Region = new Region(path);
        }


        private void btnAyarlarıKaydet_Click(object sender, EventArgs e)
        {
            
            SecilenZorluk = cmbZorluk.SelectedItem.ToString();

            
            SecilenSure = int.Parse(cmbSure.SelectedItem.ToString());

           
            SecilenTema = cmbTema.SelectedItem.ToString();

            
            this.DialogResult = DialogResult.OK;
            this.Close(); 
            if (cmbZorluk.SelectedItem == null || cmbTema.SelectedItem == null)
            {
                MessageBox.Show("Lütfen zorluk ve tema seçin.");
                return;
            }


            
            SecilenSure = (cmbSure.SelectedItem == null) ? 60 : int.Parse(cmbSure.SelectedItem.ToString());

            SecilenZorluk = cmbZorluk.SelectedItem.ToString();
            SecilenTema = cmbTema.SelectedItem.ToString();

            
            OyunAyarlar.Zorluk = cmbZorluk.SelectedItem.ToString();
            OyunAyarlar.Tema = cmbTema.SelectedItem.ToString();

           
            OyunAyarlar.Sure = int.Parse(cmbSure.SelectedItem.ToString());
           
            SecilenZorluk = OyunAyarlar.Zorluk;
            SecilenSure = OyunAyarlar.Sure;
            SecilenTema = OyunAyarlar.Tema;

            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}